# Architecture

This document describes the components, data flow, and contracts that make **Dispatch** work. It is the source of truth for the wire contract.

> Dispatch was codenamed Manager through v1.1.x. The runtime rename landed in v1.2: binary is `dispatch`, env vars are `DISPATCH_*`, state dir is `~/.claude/dispatch/`, launchd label `com.dispatch.daemon`, Xcode project `Dispatch`, Swift module `DispatchApp`. The legacy `MANAGER_*` env-var fallback was removed in v1.3 — `DISPATCH_*` only. Internal contract identifiers below (event types, MCP tool names, SQLite columns) are stable and were not renamed.

## Dispatch lexicon → contract terms

| Dispatch term (user-facing) | Contract term (internal) |
|---|---|
| **The Radar** | home view: digest + workstream cards + live event ticker |
| **The Trace** | methodology timeline rendered from `decision` / `subgoal_*` / `confidence` / `blocked` events |
| **Intercept** | intervention (`kind ∈ {nudge, redirect, rollback}`); `intervention_delivered` event |
| **The Protocol** | team handbook + `propose_skill` MCP tool + `skill_proposed` / `skill_promoted` events |
| **The Dossier** | per-workstream Markdown memory file; `update_memory` / `read_memory` MCP tools; `memory_update` event |
| Head Dispatcher | the human user of Dispatch |

## Design principles

1. **Tap, not interrupt.** Observation must never block an agent. Agents append to an event log; the manager reads projections of the log. The agent's loop is unaware of who is watching.
2. **Daemon owns state, clients are thin.** All persistent state — events, memory, queues — lives in one local daemon. UI clients (macOS now, iOS / web later) read and write only through the daemon's API. This is what lets us start macOS-native and add a remote/mobile client later without rewriting the brain.
3. **Workstream is the unit of identity, not session.** A workstream (e.g. *frontend-refactor*) spans many Claude Code sessions and carries a Markdown memory file as its accumulating context.
4. **Methodology is structured, not free-form.** Agents emit decision events with rationale and confidence. The UI renders a timeline; the raw transcript is one click away but not the default surface.
5. **Runtime-pluggable from day one.** v0 instruments Claude Code, but the event contract and intervention contract are not Claude-Code-specific. ADK 2.0, marketing pipelines, and other non-coding workflows are future implementations of the same contract.

## System overview

Dispatch supports **two operational modes** that share one telemetry path (v1.4+):

- **Observation mode** — the human launches `claude` themselves; lifecycle hooks + the MCP server feed events into the daemon. This is the v0 mode and remains the default when no `WORKFLOW.md` is configured.
- **Autonomous mode** — the orchestrator polls a tracker (Linear / mock), claims tickets, spawns `claude` per turn inside a per-issue workspace. The *same* hooks + MCP server feed the *same* event store, so Radar / Trace / Intercept work identically regardless of who launched the session.

```mermaid
graph LR
    subgraph "Agent runtime (Claude Code)"
        CC1[Session A — human-launched]
        CC2[Session B — orchestrator-spawned]
        H1[Lifecycle hooks]
    end

    subgraph "Dispatch Daemon (local, long-running)"
        ORCH["Orchestrator (v1.4)<br/>tracker poll · workspace · agent runner<br/>active only when --workflow is set"]
        MCP[MCP server<br/>emit_decision, emit_subgoal,<br/>emit_confidence, flag_blocked,<br/>update_memory, read_memory,<br/>propose_skill]
        API[HTTP / WebSocket API<br/>for clients]
        HEAD["Headliner + SubgoalSynthesizer<br/>local LLM enrichment (qwen3:4b via Ollama)"]
        ES[(Event store<br/>JSONL append-only)]
        MEM[(Workstream Dossier<br/>Markdown per workstream)]
        Q[(Intercept queue<br/>per workstream — SQLite)]
    end

    subgraph "External"
        TRK[Tracker — Linear or mock]
    end

    subgraph "Clients"
        MAC[macOS app<br/>SwiftUI]
        IOS[iOS app<br/>future v1.5]
        WEB[Web client<br/>future]
    end

    CC1 -- MCP tool calls --> MCP
    CC2 -- MCP tool calls --> MCP
    H1 -- writes JSONL --> ES
    MCP --> ES
    MCP --> MEM
    MCP --> Q
    Q -- delivered via pre-turn hook --> CC1
    Q -- delivered via pre-turn hook --> CC2

    ORCH -- claim / release / refresh --> TRK
    ORCH -- spawns per turn --> CC2
    HEAD -- reads ES, writes synthesized subgoal_push --> ES

    MAC <-- HTTP / WS --> API
    IOS -.future.-> API
    WEB -.future.-> API

    API --> ES
    API --> MEM
    API --> Q
    API --> ORCH
```

## Components

### Dispatch Daemon

Long-running local process. The only stateful component. Stack: **TypeScript / Node** — chosen for the official MCP SDK (most mature), cross-platform fit, and fast iteration. Rust remains a future option if footprint becomes a binding constraint.

Responsibilities:

- Host an **MCP server** for agents to call (decision events, memory I/O, blocking flags).
- Host an **HTTP + WebSocket API** for UI clients (subscribe to event stream, read memory, push interventions).
- Own the **event store** — append-only JSONL per workstream, plus a SQLite index when query patterns demand it.
- Own the **workstream memory** — one Markdown file per workstream, owned by the agent (via `update_memory`) and editable by the human.
- Own the **intervention queue** — per-workstream FIFO. Pre-turn hook on the agent side drains it.

State location: `~/.claude/dispatch/` (events/, memory/, db.sqlite, queues/, handbook.md, scheduler.json). The SQLite file holds the `workstreams`, `sessions`, `interventions`, `skill_proposals`, and `reports` tables; `scheduler.json` is a small JSON file written by the in-process scheduler.

#### Two-process model

In v0.5.2 the daemon role is split across two process shapes that share the on-disk state directory:

| Process | Command | Lifecycle | Surface |
|---|---|---|---|
| Long-running daemon | `dispatch start` | Started at login by the launchd agent in `~/Library/LaunchAgents/com.dispatch.daemon.plist` | HTTP/WS on `:9876` for the macOS client (and future remote clients). |
| Per-session MCP | `dispatch mcp` | Spawned by Claude Code per session via its `mcpServers` config; lives for the lifetime of one Claude Code session | MCP JSON-RPC over stdio. Binds **no** HTTP port. |

Both read and write `~/.claude/dispatch/` concurrently. SQLite is opened in WAL mode so cross-process readers/writers don't block each other; JSONL appends are atomic on POSIX (`O_APPEND`). The one race that remains is concurrent edits to the workstream memory Markdown — `MemoryStore.perWorkstreamLock` is per-process, so two MCP children writing the same section in the same millisecond is theoretically last-writer-wins. We accept this in v0.5.2 because memory edits are rare and human-paced; v1 will add an advisory file lock.

The legacy `dispatch start --mcp-stdio` mode (HTTP + MCP in one process) is kept for testing only — running it alongside the long-running daemon causes a port collision.

#### HTTP + WebSocket API contract

Localhost-only in v0/v0.5/v1; auth + remote binding land in v1.5. Default port 9876, override via `DISPATCH_PORT`. Responses are naked JSON (no envelope wrapping); errors are `{error: string}` with the HTTP status code. All Workstream payloads use the snake_case wire format documented under "Workstream" below.

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/health` | `{ok: true}` — liveness probe used by clients to choose live vs mock. |
| `GET` | `/workstreams` | Array of Workstream wire objects. |
| `POST` | `/workstreams` | Body `{id, title}` → 201 with the new Workstream wire object. |
| `GET` | `/workstreams/:id` | Workstream wire object (with `sessions[]` populated). 404 if unknown. |
| `PATCH` | `/workstreams/:id` | Body `{status?, title?}`. Validates `status` ∈ {backlog, active, paused, retired}. Updates the registry, appends a single `workstream_updated` event with `{changes, prev}`, returns the updated Workstream wire object. 404 if unknown. |
| `DELETE` | `/workstreams/:id` | Soft-delete: sets status to `retired` and appends `workstream_updated`. Returns 200 + the updated Workstream wire object (not 204) so clients can refresh local state without a follow-up GET. |
| `GET` | `/workstreams/:id/memory` | Raw Markdown body (`text/markdown`). |
| `GET` | `/workstreams/:id/events` | Array of Event JSON objects. Optional `?since=<byteOffset>`. |
| `GET` | `/workstreams/:id/decisions/:decisionId` | Full event envelope of the named `decision` event (`ts`, `workstream_id`, `session_id`, `parent_id`, `payload`). 404 if workstream or decision unknown. |
| `WS`  | `/workstreams/:id/events/stream` | Live event stream. Optional `?since=<byteOffset>` to resume. |
| `POST` | `/hooks/<event>` | Hook intake; `<event>` ∈ {session-start, stop, pre-tool-use, post-tool-use, user-prompt-submit}. |
| `POST` | `/interventions` | Body `{workstream_id, kind, payload}`. Persists into the per-workstream queue. Returns 201 with the persisted Intervention. (Accepts legacy `workstreamId` for one release.) |
| `GET` | `/workstreams/:id/interventions/pending` | Pending interventions (not yet delivered to the agent). |
| `POST` | `/workstreams/:id/interventions/ack` | Body `{ids: string[]}`. Marks delivered, appends `intervention_delivered` events. |
| `GET` | `/digest` | Aggregated rollup across all workstreams since `?since=<iso8601>` (default: 24 h ago). Returns `{since, totals: {shipped, blocked, needs_attention, active}, highlights: DigestHighlight[]}`. |
| `GET` | `/handbook` | Raw Markdown body of the team handbook (`text/markdown`). Empty body if the handbook has not been written yet. |
| `POST` | `/handbook/skills` | Body `{title, body, source?}`. Appends a `## <title>` block to the handbook with an optional source footer. Returns 201 + `{title}`. |
| `GET` | `/skills/proposed` | Array of skill proposals with `status='proposed'`, oldest first. |
| `POST` | `/skills/proposed/:id/promote` | Appends the proposal to `handbook.md`, marks `status='promoted'`, appends a `skill_promoted` event to the originating workstream's JSONL. 409 if already promoted/dismissed. |
| `POST` | `/skills/proposed/:id/dismiss` | Marks `status='dismissed'` without writing to the handbook. 409 if already promoted/dismissed. |
| `GET` | `/report-presets` | Array of built-in audience presets (`{id, name, description, system_prompt}`). |
| `POST` | `/reports/generate` | Body `{workstream_ids?, since?, until?, audience_preset?, audience_freetext?, provider, model?, save?, title?}`. Validates inputs, assembles the deterministic report context (decisions/blockers in window, memory excerpt, projections), picks the system prompt (preset OR freetext override), calls the chosen LLM provider, persists the result. Returns 201 + the persisted Report. 400 on bad provider/preset; 503 when the LLM endpoint is unreachable; 500 on other LLM errors. |
| `GET` | `/reports` | Naked array of Reports, ordered by `generated_at DESC`. Optional `?status=draft|saved|archived`; default hides `archived`. |
| `GET` | `/reports/:id` | Single Report. 404 if unknown. |
| `PATCH` | `/reports/:id` | Body `{title?, body_md?, status?}`. Updating `status` to `'saved'` sets `saved_at = now()`. |
| `DELETE` | `/reports/:id` | Soft-delete: sets `status='archived'` and returns 200 + the updated Report. |
| `GET` | `/scheduler/jobs` | Naked array of `{id, enabled, cron, audience_preset, provider, model, next_fire_at}`. |
| `PATCH` | `/scheduler/jobs/:id` | Body `{enabled?, cron?, audience_preset?, provider?, model?}`. Validates the cron expression eagerly, persists the change to `~/.claude/dispatch/scheduler.json`, recomputes `next_fire_at`, and returns the updated job. 404 on unknown id; 400 on invalid cron / preset / provider. |
| `GET` | `/workstreams/:id/link` | v1.2 — `WorkstreamLink \| null`. The `null` body distinguishes "linked nothing yet" from "workstream not found" (404). |
| `PUT` | `/workstreams/:id/link` | v1.2 — Body `{tracker_kind: 'linear', issue_identifier: string}`. Resolves via `LinearTracker.fetchIssueByIdentifier` and persists. 503 with `code: 'linear_api_key_missing'` when no key is configured; 400 with `code: 'linear_unknown_identifier'` when the tracker can't find the issue; 404 when the workstream doesn't exist. |
| `DELETE` | `/workstreams/:id/link` | v1.2 — Idempotent unlink. Returns 200 even when no prior link existed. |
| `GET` | `/links` | v1.2 — Naked array of every persisted `WorkstreamLink`. |
| `POST` | `/admin/llm/kill` | v1.4.6 — Resolves the configured local-LLM base URL, finds the listener PID via `lsof -i tcp:<port> -sTCP:LISTEN -t`, sends SIGTERM with a 3-second grace period before SIGKILL. Returns `{killed: pid \| null, escalated: bool, error?: string}`. 200 always (200 + `killed: null` when nothing was running). |
| `POST` | `/admin/llm/restart` | v1.4.6 — Same kill flow, then runs `localLLMStartCommand` from settings via `bash -lc <cmd>` detached + `unref()`. Returns `{killed_pid, started, error?}`. 400 with `code: 'no_start_command'` when the command isn't configured. |
| `POST` | `/admin/restart` | v1.4.6 — Soft daemon restart: cancels + re-instantiates Headliner / SubgoalSynthesizer / LinearCommentSyncer in place after re-reading `settings.json`. Returns `{restarted: string[]}`. The daemon process keeps its PID — hard restart (full launchd respawn) lives client-side. |

### Agent-side instrumentation (Claude Code, v0)

Two channels feed the daemon:

**Lifecycle hooks** (zero-touch — the agent doesn't know they exist):

| Hook | What it emits |
|---|---|
| `SessionStart` | session attaches to workstream, registers identity |
| `UserPromptSubmit` | drains the intervention queue for this workstream, prepends any nudges/redirects/rollbacks to the next turn |
| `PreToolUse` / `PostToolUse` | tool-call events (low-fidelity activity) |
| `Stop` | session ended, status update |

**MCP tools** (called explicitly by the agent — high-fidelity):

| Tool | Purpose |
|---|---|
| `emit_decision(considered, choice, rationale, confidence, parent_id?)` | structured decision point, the unit the timeline is built from |
| `emit_subgoal(goal, parent_id?)` | push a sub-goal onto the agent's goal stack |
| `emit_confidence(value, note?)` | spot-update confidence outside a decision |
| `flag_blocked(reason)` | escalate — sets the "needs you" flag in the UI |
| `update_memory(section, content)` | write into the workstream memory MD |
| `read_memory(section?)` | read it back |
| `propose_skill(title, body, source_decision_id?)` | propose a pattern for promotion to the team handbook (manager reviews and promotes via the macOS app) |
| `ask_user(question, options?, allow_freetext?, context?, timeout_seconds?)` | v1.4.7 — block on a human answer surfaced as a `question_required` intervention strip in the workstream detail view; returns `{answered, choice?, freetext?}` or `{answered:false, reason:"timeout"}` |

Agent prompt (system message added at workstream start) instructs the agent to call `emit_decision` at each non-trivial fork and `update_memory` whenever it learns something a future session of this workstream should know.

### Clients

**macOS app (v0):** SwiftUI. Talks to the daemon over `localhost` HTTP/WebSocket. Renders the home view (digest rail, team floor, ticker) and agent detail (timeline, memory pane, intervention controls).

**iOS / web (future):** same API contract, different rendering. The daemon exposes its API on localhost only in v0; v1.5 adds authenticated remote access for mobile.

#### URL scheme (v1.3+)

The macOS app registers `dispatch://` in its `CFBundleURLTypes`. Today only one shape is recognized: `dispatch://workstream/<slug>` selects the matching workstream in the Radar (or surfaces a "not found — open `claude` here to register" banner if the daemon hasn't seen that id yet). The Claude Code `/dispatcher` slash command (`commands/dispatcher.md`) derives a slug from the current git root using the same rules as `hooks/_common.sh:dispatch__slugify` and shells out to `open dispatch://workstream/<slug>` so the agent can drop the human into the matching card. Parser implementations: `daemon/src/url-scheme.ts` (canonical) and `client-macos/Dispatch/Daemon/DispatchURLParser.swift` (Swift port; same accept/reject set).

#### Admin endpoints (v1.4.6 Diagnostics)

Three POST endpoints on the daemon back the macOS Settings → Diagnostics tab. `POST /admin/llm/kill` and `POST /admin/llm/restart` resolve the configured local-LLM base URL through the same env > settings > default chain `SettingsStore.getResolvedOllamaUrl()` uses, find the listener PID via `lsof -i tcp:<port> -sTCP:LISTEN -t`, SIGTERM with a 3-second grace period before SIGKILL, and (for `restart`) run the user-configured `localLLMStartCommand` via `bash -lc <cmd>` detached + `unref()`. `POST /admin/restart` is a soft restart that cancels + re-instantiates the daemon's tickers (Headliner / SubgoalSynthesizer / LinearCommentSyncer) in place so a Settings change takes effect without exiting; the **hard** restart (full process respawn) is the macOS app's responsibility — it shells out to `launchctl kickstart -k gui/<uid>/com.dispatch.daemon` via `LaunchctlController` rather than hitting a daemon endpoint, because the daemon would die mid-response. Pure helpers in `daemon/src/admin.ts` (`parseHostPort`, `findPidOnPort`, `killWithEscalation`, `spawnDetached`) are the side-effect seams; every helper takes injectable mocks so the test suite never actually shells out.

### Orchestrator (v1.4 — autonomous mode)

The orchestrator is the second runtime path into the daemon. Activated only when `dispatch start --workflow <path>` is passed; without that flag the daemon stays purely observational. The architecture follows OpenAI's [Symphony](https://github.com/openai/symphony) spec; we adopted §7–§11 verbatim and bolted them onto our existing telemetry path so observation features (Radar, Trace, Intercept, Protocol) work for orchestrator-spawned agents with zero new code on the presentation side.

Five components, all in `daemon/src/`:

| Component | File | Responsibility |
|---|---|---|
| **State machine** | `orchestrator.ts` | Symphony §7 — per-issue lifecycle (`Unclaimed → Claimed → Running → RetryQueued / Released`). Symphony §8 candidate selection + sort. §8.4 retry/backoff. §8.5 reconciliation tick. |
| **Tracker adapter** | `trackers/{linear,mock}.ts` | Pluggable. Symphony §11 GraphQL for Linear; the mock reads a JSON file for tests. Common interface: `listIssues`, `claim`, `release`, `setState`. |
| **Workflow loader** | `workflow-loader.ts` | Reads `WORKFLOW.md` — YAML front matter + Markdown prompt template. Env var indirection (`api_key: $LINEAR_TOKEN`). Dynamic reload via `fs.watch` + 60-second backstop poll. |
| **Workspace manager** | `workspaces.ts` | Symphony §9 — one directory per claimed issue under `workspace.root`. Sanitized key `[A-Za-z0-9._-]`, safety invariants (path containment, refusal to delete outside root). Pre/post hooks via `bash -lc` with timeout. Reuses the dir across runs of the same issue. |
| **Agent runner** | `agent-runner.ts` | Spawns `claude` per turn inside the workspace (option A of Symphony §10). Sets `DISPATCH_WORKSTREAM` + `DISPATCH_SESSION_ID` so the existing hooks + MCP route events to the right workstream — no parallel telemetry path. Captures stderr tail, maps exit codes to Symphony §10.6 error categories (`turn_timeout`, `turn_failed`, `codex_not_found`, `spawn_error`). |

**Telemetry equivalence.** The orchestrator does not emit any new event types. A spawned `claude` session writes the same `session_start` / `tool_use` / `decision` / `subgoal_push` / etc. that a human-launched session writes — because it *is* the same `claude`, with the same hooks installed and the same MCP server attached. The only orchestration-specific surface is `GET /orchestrator/state` (Symphony §13.7.2 snapshot) for the macOS client to render an "autonomous" badge on cards spawned by the orchestrator.

**Approval bridge (v1.4.4).** When an autonomous agent needs human authorization for a destructive or out-of-scope action it enqueues an `approval_required` intervention. The macOS `AgentDetailView` renders an `ApprovalStrip` between the header and the timeline; tapping Approve / Deny calls `POST /workstreams/:id/interventions/:intId/decide`, which atomically merges the decision into the queue and emits `intervention_delivered` with `approved: bool`. The agent-side trigger (an MCP tool that enqueues approval requests) is deferred to v1.4.5; until then the queue + API + UI infra ships ahead of any source that fills it.

**Question bridge (v1.4.7).** Same shape as the approval bridge, one intervention kind down: `ask_user` MCP tool → `question_required` intervention → `QuestionStrip` between the header and the timeline → `POST /workstreams/:id/interventions/:intId/answer` with `{choice?, freetext?}`. The MCP handler blocks the agent's tool call (polling SQLite once per second, capped at the agent-supplied `timeout_seconds`, default 300) and returns the manager's pick to the agent. Lets the agent route a question to Dispatch instead of blocking the terminal session — the user picks an option in the app and the agent unblocks.

**WORKFLOW.md schema (minimum viable):**

```markdown
---
tracker:
  kind: linear              # or `mock` for tests
  project_slug: my-project
  api_key: $LINEAR_TOKEN    # env var indirection — loader resolves at boot
  active_states: [Todo, In Progress]
  terminal_states: [Done, Cancelled]
polling:
  interval_ms: 30000
workspace:
  root: ~/Code/dispatch-workspaces
agent:
  runtime: claude-code
  max_concurrent_agents: 3
hooks:
  pre_turn:  "git fetch && git checkout -b ds/{{ issue.identifier | lower }}"
  post_turn: "git status -s"
  timeout_ms: 60000
---

You are working on {{ issue.identifier }}: {{ issue.title }}.

{% if attempt %}This is attempt #{{ attempt }} after a previous failure.{% endif %}

Description:
{{ issue.description }}
```

The Markdown body is the **prompt template** rendered per turn with the issue context. The minimal renderer supports `{{ issue.* }}` substitution and a single `{% if attempt %}` conditional — no full Liquid/Jinja runtime.

### LLM-driven enrichment (Headliner + SubgoalSynthesizer)

Two background tickers in the daemon run a small local model (default `qwen3:4b` against any OpenAI-compatible local server — `mlx_lm.server`, Ollama, llama.cpp; pointed at via `DISPATCH_LLM_BASE_URL`, default `http://localhost:8080/v1`) to add narrative on top of the raw event log:

- **Headliner** (`daemon/src/headliner.ts`) — every ~30s, regenerates a one-sentence "Currently:" summary per workstream from the recent event window. Surfaced as `Workstream.activity_headline`. The macOS HomeView card prefers it over `latest_activity`.
- **SubgoalSynthesizer** (`daemon/src/subgoal-synthesizer.ts`) — same cadence, watches each workstream for runs of ≥8 consecutive `post-tool-use` events with no agent-emitted narration in between (no `decision`, `subgoal_push`, `blocked`, …). Each such window is summarized as a single present-progressive sentence and **written back to the event log as a `subgoal_push` event** with two extra payload fields: `source: "synthesized"` and `synth_anchor: "<firstId>..<lastId>"`. The anchor is read back from the log on every tick so the same window is never summarized twice — synthesis is idempotent across daemon restarts. Disabled with `DISPATCH_SUBGOAL_SYNTH_ENABLED=0`.

Both tickers degrade silently when the LLM endpoint is unreachable; the deterministic projections (`latest_activity`, raw `tool_use` rows) remain the fallback.

The macOS timeline renders synthesized sub-goals with a 🤖 prefix and collapses runs of raw `tool_use` rows into an "N actions ▸" pill so the human sees story + sub-story rather than a list of bash calls — see `client-macos/Dispatch/Views/AgentDetailView.swift`.

### Tracker links (v1.2)

The link table is the manual analogue of the orchestrator's auto-claim path: a human links a Dispatch workstream to a tracker issue once, and the daemon then ferries decisions out to the tracker as comments and tracker-state changes back into the workstream's `status` field.

**SQLite schema** (`daemon/src/workstream-links-store.ts`):

```sql
CREATE TABLE workstream_links (
  workstream_id    TEXT PRIMARY KEY,
  tracker_kind     TEXT NOT NULL,         -- 'linear' for v1.2; future: 'github_issues', 'jira', …
  issue_id         TEXT NOT NULL,         -- tracker-internal id (Linear node id)
  issue_identifier TEXT NOT NULL,         -- human identifier (ENG-123)
  issue_url        TEXT,
  last_seen_state  TEXT,                  -- last tracker state we observed
  last_synced_at   TEXT,                  -- ISO 8601 of last successful round-trip
  created_at       TEXT NOT NULL,
  FOREIGN KEY (workstream_id) REFERENCES workstreams(id)
);
CREATE INDEX idx_links_issue ON workstream_links(issue_id);
CREATE TABLE linear_comments_posted (
  decision_id   TEXT PRIMARY KEY,
  workstream_id TEXT NOT NULL,
  posted_at     TEXT NOT NULL
);
```

**HTTP surface.** Four endpoints (`GET/PUT/DELETE /workstreams/:id/link`, `GET /links`) — see the table above.

**`LinearCommentSyncer` ticker** (`daemon/src/linear-comment-syncer.ts`). Cadence 60 s (`tickIntervalMs`); disable with `DISPATCH_LINEAR_SYNC_ENABLED=0`.

- *Forward (Dispatch → Linear):* for every linked workstream, scan the event log for `decision` events with `payload.confidence >= DISPATCH_LINEAR_COMMENT_MIN_CONFIDENCE` (default `0.8`). For each one not already in `linear_comments_posted`, render a deterministic Markdown body and call `addIssueComment`. On success, mark the decision id posted. `linear_comment_failed` errors are swallowed and retried next tick — the set is only updated on confirmed success, so retries can't double-post.
- *Reverse (Linear → Dispatch):* `fetchIssueStatesByIds` across linked issues. When the new state differs from `last_seen_state` we apply the state map below — but **only** if the workstream's *current* Dispatch status equals what the previous Linear state mapped to, i.e. the human hasn't manually overridden. State map: `Done|Closed|Cancelled|Canceled→retired`, `In Progress→active`, `Backlog|Todo→backlog`, `On Hold|Paused→paused`, anything else → silent skip + log once. The CLI wires `onWorkstreamUpdated` so a flip appends a `workstream_updated` event with `payload.source: 'linear_sync'`.

Reachability failures (`fetchIssueStatesByIds` rejects, individual `addIssueComment` fails) are logged + swallowed at tick-scope so a temporary Linear outage doesn't crash the daemon.

## Data model

### Workstream

Wire format served by `GET /workstreams` and `GET /workstreams/:id` (snake_case JSON):

```
workstream_id      : string (slug, e.g. "frontend-refactor")
title              : string
created_at         : ISO 8601 timestamp
status             : backlog | active | paused | retired
memory_path        : absolute path to ~/.claude/dispatch/memory/<workstream_id>.md
sessions           : [session_id, ...]   # all Claude Code sessions that ran under this workstream
current_subgoal    : string | null       # head of the goal stack, or null if none
latest_confidence  : number | null       # 0-1, from the most recent decision/confidence event
needs_attention    : boolean             # true after a flag_blocked event until cleared
last_event_at      : ISO 8601 timestamp | null   # most recent activity (cheap mtime approximation in v0)
```

A workstream is the persistent identity. Sessions come and go. The four projection fields drive the home-view cards and are computed as follows:

- `current_subgoal`: head of the goal stack obtained by walking `subgoal_push` / `subgoal_pop` events in chronological order.
- `latest_confidence`: the most recent (by `ts`) numeric confidence from either a `confidence` event (`payload.value`) or a `decision` event (`payload.confidence`).
- `needs_attention`: `true` iff there is a `blocked` event with no later `session_end` for the same `session_id` (a `blocked` event without a `session_id` is resolved by any later `session_end`).
- `last_event_at`: cheap approximation from the JSONL file mtime.

In v0.5.1 these are recomputed by re-reading the per-workstream events file on each `GET /workstreams[/:id]` request — fine for current file sizes; v1 will index them in SQLite and update incrementally on append.

### Event (JSONL line in events store)

```json
{
  "ts": "2026-05-02T22:30:14.123Z",
  "workstream_id": "frontend-refactor",
  "session_id": "01J...",
  "type": "decision",
  "id": "dec_07",
  "parent_id": "dec_05",
  "payload": {
    "considered": ["use react-query", "use SWR", "roll our own"],
    "choice": "use react-query",
    "rationale": "team already has a react-query setup in the API package; SWR adds a dep without payoff",
    "confidence": 0.8
  }
}
```

Event types: `session_start`, `session_end`, `decision`, `subgoal_push`, `subgoal_pop`, `confidence`, `tool_use`, `blocked`, `memory_update`, `intervention_enqueued`, `intervention_delivered`, `workstream_updated`, `skill_proposed`, `skill_promoted`.

**Payload extensions.** A `subgoal_push` event with `payload.source = "synthesized"` was written by the SubgoalSynthesizer rather than the agent itself; `payload.synth_anchor` carries the deterministic window key (`<firstToolUseId>..<lastToolUseId>`) used for cross-restart idempotency. The macOS client uses `source` to render a 🤖 marker on the row; everything else (timeline ordering, intercept eligibility, projection inputs) treats the event identically to an agent-emitted sub-goal.

### Workstream memory (Markdown)

Free-form Markdown file the agent maintains. Convention:

```markdown
# Workstream: frontend-refactor

## Goal
Migrate the dashboard package from Redux to react-query.

## Current state
- Phase 2 of 4 — auth queries done, billing queries in progress.

## Key decisions
- 2026-05-02 — chose react-query over SWR (see decision dec_07).

## Open questions
- Whether to keep Redux for offline-cached views or drop it entirely.

## Skills learned
- Pattern for migrating mutation-heavy slices (see decision dec_12).
```

Owned by the agent, edited via `update_memory`. Human can edit directly; next agent session reads the file at `SessionStart` and treats it as ground truth.

### Intervention

```json
{
  "id": "int_42",
  "workstream_id": "frontend-refactor",
  "kind": "nudge | redirect | rollback",
  "payload": {
    "message": "consider whether react-query handles your offline case",
    "rollback_to_decision_id": "dec_05"   // only for kind=rollback
  },
  "created_at": "...",
  "delivered_at": null
}
```

Field names are snake_case on the wire (matching every other endpoint). `delivered_at` stays `null` until the agent's `UserPromptSubmit` hook acks delivery via `POST /workstreams/:id/interventions/ack`. The hook drains in two steps — `GET .../interventions/pending` then `POST .../interventions/ack` — so a transport failure on ack does not lose interventions: they remain pending and re-emit on the next turn. The small accepted risk is duplicate context if the ack fails after the agent has already received the pending list; v1 may add an idempotency token to suppress re-emission. `intervention_delivered` events are appended to the JSONL event store on each successful ack so the methodology timeline shows when the intervention was picked up.

## Event flow: agent emits, manager renders, human nudges

```mermaid
sequenceDiagram
    autonumber
    participant H as Human
    participant M as macOS Client
    participant D as Daemon
    participant A as Claude Code Agent

    A->>D: SessionStart hook → register session under workstream
    D-->>M: stream: session_start event
    A->>D: emit_decision(...)
    D->>D: append JSONL, index in SQLite
    D-->>M: stream: decision event
    M-->>H: render in timeline (live)
    H->>M: types nudge "consider X"
    M->>D: POST /interventions {kind:nudge, ...}
    D->>D: enqueue
    A->>D: UserPromptSubmit hook (next turn) — drain queue
    D-->>A: returns pending interventions
    A->>A: agent reads injected guidance, adjusts course
    A->>D: emit_decision(...) reflecting the adjustment
    D-->>M: stream: decision event
    M-->>H: timeline shows the change
```

## Workstream model: persistence across sessions

```mermaid
graph TD
    W[Workstream: frontend-refactor]
    W --> MEM[memory.md - persists forever]
    W --> S1[Session 1 - Mon morning]
    W --> S2[Session 2 - Mon afternoon]
    W --> S3[Session 3 - Tue]
    S1 --> E1[events.jsonl]
    S2 --> E2[events.jsonl]
    S3 --> E3[events.jsonl]
    MEM -. read at SessionStart .-> S1
    MEM -. read at SessionStart .-> S2
    MEM -. read at SessionStart .-> S3
    S1 -. update_memory writes .-> MEM
    S2 -. update_memory writes .-> MEM
    S3 -. update_memory writes .-> MEM
```

Each session reads the memory file at start, updates it during work, and the next session inherits the latest state. Decision events accumulate across all sessions of the workstream — the timeline is a continuous record, not per-session.

## Intervention semantics

```mermaid
graph LR
    H[Human action] --> N{Mode?}
    N -->|Nudge| NA[Advisory note injected at next turn.<br/>Agent may or may not change course.]
    N -->|Redirect| RA[Hard course-correct.<br/>Agent must respond, may not continue prior path.]
    N -->|Rollback| RB[Frame as: 'we are back at decision X.<br/>Reconsider with this hint.'<br/>Agent re-decides from that branch.]
    NA --> Q[Pending in intervention queue]
    RA --> Q
    RB --> Q
    Q --> D[Pre-turn hook drains queue,<br/>prepends to next user prompt]
```

**Rollback is implemented as replay-with-hint, not session-state restoration.** The daemon constructs a message that frames the rollback ("we are returning to decision dec_05; here is what was considered then; here is the new hint") and queues it. The agent treats it as a strong redirect. This keeps v0 simple — no checkpoint or KV-state plumbing. v1+ may add true session-state checkpoints if the replay-with-hint approach proves insufficient.

## Skill broadcast

A team handbook (`~/.claude/dispatch/handbook.md`) is the shared knowledge surface for every workstream's agent. The propose → promote → adopt loop:

1. **Agent proposes.** Mid-session, an agent calls the `propose_skill(title, body, source_decision_id?)` MCP tool when it discovers a pattern other workstreams should reuse. The daemon persists the proposal into the SQLite-backed `SkillProposalsStore` (`status='proposed'`) and appends a `skill_proposed` event to the originating workstream's JSONL log.
2. **Manager reviews.** The macOS app polls `GET /skills/proposed` and renders pending proposals. The human clicks **Promote** or **Dismiss**.
3. **Daemon promotes.** `POST /skills/proposed/:id/promote` calls `HandbookStore.appendSkill(title, body, {workstream_id, decision_id})`, which appends a `## <title>` block to `handbook.md` with a source footer (`_(from workstream … / decision …)_`). The proposal row flips to `status='promoted'`. A `skill_promoted` event is appended to the originating workstream's JSONL.
4. **Agents adopt.** On the next `SessionStart` for any workstream, the lifecycle hook fetches `GET /handbook` and inlines the contents as `additionalContext`. From then on, every session has the new pattern in its working context (until the inlined snippet is evicted by Claude Code's context window).

The handbook is a single Markdown file, not one file per skill — keeps inlining cheap, keeps merging simple. Single writer (the manager via the macOS app); agents are read-only on the handbook itself, write-only into the proposal queue.

## Reports (v1.1)

The reports surface lets the human (or the scheduler) generate written updates summarising one or more workstreams over a chosen period. The implementation has four pieces:

1. **Report context (`daemon/src/report-engine.ts`)** — a pure function `assembleReport({registry, eventStore, memoryStore}, {workstream_ids, since, until})` that returns a `ReportContext`:

   ```
   ReportContext { since, until, workstreams: WorkstreamSnapshot[] }
   WorkstreamSnapshot {
     id, title, status,
     current_subgoal, latest_confidence, needs_attention,    # projection fields
     decisions_in_window, blockers_in_window,                # capped most-recent slices
     memory_excerpt,                                         # last ~2KB of memory MD
     shipped_count, active_seconds                           # in-window aggregates
   }
   ```

   Decisions are capped at the 30 most recent per workstream; the memory excerpt is the last 2KB of the markdown file, with an `(…older sections truncated)` notice when the original was longer. Unknown workstream ids are silently skipped — the function never throws.

2. **Audience presets vs. free-text override (`daemon/src/report-presets.ts`)** — four built-in presets ship with the daemon: `executive`, `business_partner`, `engineer_peer`, `sponsor`. Each carries a tailored `system_prompt`. The HTTP layer also accepts an `audience_freetext` field; **when non-empty, the freetext replaces the preset's system prompt entirely** with `"You write an update for: <freetext>. Adapt the structure and tone to suit. Be concrete and avoid filler."`. The override always wins.

3. **Pluggable LLM providers (`daemon/src/llm/`)**:

   | Provider | Transport | Default model | Credentials | Failure modes |
   |---|---|---|---|---|
   | `claude` | `@anthropic-ai/sdk` (`messages.create`) | `claude-sonnet-4-7` | `ANTHROPIC_API_KEY` env var | Missing key → `LLMConfigError` (HTTP 500). SDK errors → `LLMRequestError` (HTTP 500) preserving the upstream status. |
   | `ollama` | HTTP POST to `${baseUrl}/chat/completions` (OpenAI-compat, non-streaming). Base URL is `DISPATCH_LLM_BASE_URL` → settings.json `ollamaUrl` → `OLLAMA_URL` (legacy alias) → `http://localhost:8080/v1` (mlx_lm.server). Bare `http://localhost:11434` and any URL without `/v1` in the path get `/v1` auto-appended for backwards compatibility with v1.2 Ollama setups. | `qwen3:8b` | none (local) | Connection refused → `LLMUnreachableError` (HTTP 503) with install hint `"pip install mlx-lm && mlx_lm.server --port 8080"` or `"brew install ollama && ollama serve"`. Non-2xx → `LLMRequestError`. |

   The `ollama` provider name is the family name for "any OpenAI-compatible local server" — mlx_lm.server (Apple's MLX engine, the recommended default on M-series silicon as of v1.3), Ollama, llama.cpp, etc. Both providers are constructed via `getProvider(name, overrides?)`; the HTTP layer translates the typed errors to status codes so the macOS client can render them differently (config issue vs. local LLM not running).

4. **Saved reports store (`daemon/src/report-store.ts`)** — a SQLite table on the existing `~/.claude/dispatch/db.sqlite`:

   ```
   reports(id PK, title, audience_preset, audience_freetext, period_since, period_until,
           workstream_ids_json, provider, model, body_md, status, generated_at, saved_at)
   ```

   Status flow: `draft` → `saved` (sets `saved_at`) → `archived` (soft-delete, hidden from default list). The `workstream_ids` column is a JSON-encoded array — kept inline rather than normalised to a join table since the cardinality is small and reports are immutable bodies.

5. **Scheduler (`daemon/src/scheduler.ts`)** — in-process loop wrapping the `croner` package. Persists per-job config to `~/.claude/dispatch/scheduler.json`:

   ```json
   {
     "weekly_report":  {"enabled": false, "cron": "0 8 * * 1", "audience_preset": "executive", "provider": "claude"},
     "monthly_report": {"enabled": false, "cron": "0 8 1 * *", "audience_preset": "executive", "provider": "claude"}
   }
   ```

   On boot the scheduler reads the file (seeding defaults if absent), computes each enabled job's next fire time relative to *now* (no backfill of fires the daemon was offline for), and arms a 60-second tick that fires due jobs and advances their next-fire time to the next future tick. A fired job calls `assembleReport` for every `status='active'` workstream, generates via the configured provider/preset, and persists the result with `status='draft'` so the human reviews before sharing.

   Trade-offs accepted in v1.1:
   - **No backfill on missed ticks.** A daemon offline over a Monday morning will not retroactively generate the missed weekly report — the next fire is the *next* Monday at the configured time. Predictable and avoids hammering the LLM after a long downtime; v1.2 may add an opt-in catch-up.
   - **Same input, different output.** Saved reports are immutable bodies — regenerating produces a new row rather than overwriting.
   - **API key never logged.** `ANTHROPIC_API_KEY` is read from the process environment and passed only to the SDK constructor; v1.2 may add per-machine encrypted storage.

## Open architectural questions

1. **API auth for remote/mobile**: how clients authenticate when the daemon is exposed beyond localhost. Deferred to v1.5; localhost-only for v0/v0.5/v1.
2. **Multi-machine workstreams**: do workstreams ever span machines (laptop + cloud)? Out of scope for v0; assume single-machine.
3. **Skill broadcast storage**: shared team handbook is one Markdown file vs one file per skill. Decided when v1 begins.
